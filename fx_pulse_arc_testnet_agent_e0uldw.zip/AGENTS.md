# FX Pulse — Project Memory

## Deployed Contracts (Arc Testnet, chainId 5042002)

| Contract | Address | Explorer |
|---|---|---|
| ReportDesk | 0xb88ce5fb990b8c47fa5edfe2f4aed36ba7d4db7b | https://explorer.testnet.arc.io/address/0xb88ce5fb990b8c47fa5edfe2f4aed36ba7d4db7b |

## ERC-8004 Registries (Arc Testnet)

| Registry | Address |
|---|---|
| IdentityRegistry (testnet) | 0x8004A818BFB912233c491871b3d84c89A494BD9e |
| ReputationRegistry (testnet) | 0x8004B663056A597Dffe9eCcC1965A193B7388713 |
| IdentityRegistry (mainnet comment only) | 0x8004A169FB4a3325136EB29fA0ceB6D2e539a432 |
| ReputationRegistry (mainnet comment only) | 0x8004BAa17C55a88189AE136b182e5fdA19dE9b63 |

## Agent Registration

The ERC-8004 agent token ID is recorded in `ReportDesk.agentTokenId` once the owner calls
`setAgentTokenId(tokenId)` after registering via `IdentityRegistry.register(agentURI)`.

Agent card served at: `/agent.json` (public static file).

## Key Notes

- USDC ERC-20 (6 decimals): 0x3600000000000000000000000000000000000000
- Report fee: 500_000 (= 0.50 USDC, 6 dec atomic units)
- Publish window: 900 seconds (15 minutes). Owner cannot publish after this window; buyer may refund.
- `_pendingFees` tracks locked USDC; `withdrawFees` only releases earned (published) fees.
- Deployer wallet (Mode 1 platform): 0x5B12Ce46C7194aD57d143bC22847224047b1Ef42
