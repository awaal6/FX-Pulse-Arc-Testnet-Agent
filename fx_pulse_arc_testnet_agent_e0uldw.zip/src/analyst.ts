/**
 * FX Pulse — Offchain analyst stub + optional live feed.
 *
 * If VITE_PRICE_API_URL is set, we fetch last price and 24h change.
 * Otherwise we use a deterministic stub: bias from djb2(pair+utcHour),
 * confidence 50-70, canned drivers, mid/change = null.
 *
 * Output is pure research. Not financial advice, not an order router.
 */

export type Pair = 'USDC/EURC' | 'USDC/GBPA' | 'USDC/JPYC'
export const PAIRS: Pair[] = ['USDC/EURC', 'USDC/GBPA', 'USDC/JPYC']

export type Bias = 'long_base' | 'long_quote' | 'neutral'

export interface FXNote {
  pair: string
  bias: Bias
  confidence: number
  horizon: '24h'
  drivers: [string, string, string]
  mid: number | null
  change24hPct: number | null
  generatedAt: string
  disclaimer: string
  isStub: boolean
}

// djb2 hash
function djb2(s: string): number {
  let h = 5381
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) + h) ^ s.charCodeAt(i)
    h = h >>> 0 // keep unsigned 32-bit
  }
  return h
}

const CANNED_DRIVERS: Record<Pair, [string, string, string]> = {
  'USDC/EURC': [
    'EURC reserve transparency reports show stable EUR backing — no peg deviation.',
    'Cross-chain USDC/EURC liquidity pools on Arc show tightening spreads vs prior session.',
    'ECB forward guidance unchanged; euro-area short rates capped near 3.5% — stub feed, not live prices.',
  ],
  'USDC/GBPA': [
    'GBPA minting activity expanded 0.8% week-on-week, outpacing USDC net issuance on Arc.',
    'UK CPI expectations muted; BoE rate path largely priced in — muted directional bias.',
    'On-chain GBPA/USDC depth in Arc AMMs is thinner vs EURC pair — wider fair-value band — stub feed, not live prices.',
  ],
  'USDC/JPYC': [
    'JPYC backing is 100% yen deposits; BOJ ultra-loose stance still intact per last meeting.',
    'Risk-off bid for JPY proxies in TradFi has not visibly flowed into JPYC on-chain supply.',
    'Arc JPYC volume is small — thin order books amplify price impact — stub feed, not live prices.',
  ],
}

function stubNote(pair: Pair): FXNote {
  const utcHour = new Date().getUTCHours()
  const seed = djb2(pair + String(utcHour))
  const biasIdx = seed % 3
  const bias: Bias = biasIdx === 0 ? 'long_base' : biasIdx === 1 ? 'long_quote' : 'neutral'
  const confidence = 50 + (seed % 21) // 50-70

  return {
    pair,
    bias,
    confidence,
    horizon: '24h',
    drivers: CANNED_DRIVERS[pair],
    mid: null,
    change24hPct: null,
    generatedAt: new Date().toISOString(),
    disclaimer:
      'Research only. Not financial advice. Not an offer to trade.',
    isStub: true,
  }
}

async function fetchLivePrice(
  pair: Pair,
): Promise<{ last: number; change24hPct: number } | null> {
  const base: string | undefined = import.meta.env.VITE_PRICE_API_URL as string | undefined
  if (!base) return null
  try {
    const url = `${base}?pair=${encodeURIComponent(pair)}`
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), 5000)
    const res = await fetch(url, { signal: ctrl.signal })
    clearTimeout(timer)
    if (!res.ok) return null
    const data = (await res.json()) as { last?: number; change24hPct?: number }
    if (typeof data.last !== 'number') return null
    return { last: data.last, change24hPct: data.change24hPct ?? 0 }
  } catch {
    return null
  }
}

export async function generateNote(pair: Pair): Promise<FXNote> {
  const live = await fetchLivePrice(pair)
  const base = stubNote(pair)
  if (!live) return base

  // With live data, adjust bias from change
  const bias: Bias =
    live.change24hPct > 0.1
      ? 'long_base'
      : live.change24hPct < -0.1
        ? 'long_quote'
        : 'neutral'
  const confidence = Math.min(90, Math.max(50, 60 + Math.round(Math.abs(live.change24hPct) * 10)))
  const drivers: [string, string, string] = [
    `Mid rate ${live.last.toFixed(5)} — ${live.change24hPct >= 0 ? '+' : ''}${live.change24hPct.toFixed(3)}% vs prior 24h.`,
    base.drivers[1],
    base.drivers[2].replace(' — stub feed, not live prices', ''),
  ]

  return {
    pair,
    bias,
    confidence,
    horizon: '24h',
    drivers,
    mid: live.last,
    change24hPct: live.change24hPct,
    generatedAt: new Date().toISOString(),
    disclaimer: base.disclaimer,
    isStub: false,
  }
}

/** Produce a canonical JSON string for keccak256 hashing. */
export function canonicalJson(note: FXNote): string {
  return JSON.stringify({
    pair: note.pair,
    bias: note.bias,
    confidence: note.confidence,
    horizon: note.horizon,
    drivers: note.drivers,
    mid: note.mid,
    change24hPct: note.change24hPct,
    generatedAt: note.generatedAt,
    disclaimer: note.disclaimer,
  })
}
