import { useState } from 'react'
import { useReadContract } from 'wagmi'
import { ChevronDown, ChevronUp, FileText, Clock } from 'lucide-react'
import { REPORT_DESK_ADDRESS, REPORT_DESK_ABI } from '../contracts'

const CHAIN_ID = 5042002

const REFUND_SENTINEL =
  '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'

interface ReportRowProps {
  reportId: bigint
}

interface ReportStruct {
  reportId: bigint
  buyer: `0x${string}`
  pairId: `0x${string}`
  paidAt: bigint
  fee: bigint
  contentHash: `0x${string}`
  published: boolean
}

// Capture once at component render to avoid impure Date.now in React Compiler context
const LOAD_TIME_MS = Date.now()

function ReportRow({ reportId }: ReportRowProps) {
  const [expanded, setExpanded] = useState(false)

  const { data: report } = useReadContract({
    address: REPORT_DESK_ADDRESS,
    abi: REPORT_DESK_ABI,
    functionName: 'getReport',
    args: [reportId],
    chainId: CHAIN_ID,
  }) as { data: ReportStruct | undefined }

  if (!report) return null

  const isRefunded = report.contentHash === REFUND_SENTINEL
  const isPublished = report.published && !isRefunded
  const isPending = !report.published
  const paidAtDate = new Date(Number(report.paidAt) * 1000)
  const refundAt = new Date((Number(report.paidAt) + 900) * 1000)
  const canRefund = isPending && LOAD_TIME_MS >= refundAt.getTime()

  const statusColor = isPublished
    ? 'var(--success)'
    : isRefunded
      ? 'var(--muted)'
      : canRefund
        ? 'var(--danger)'
        : 'var(--accent)'

  const statusLabel = isPublished
    ? 'Published'
    : isRefunded
      ? 'Refunded'
      : canRefund
        ? 'Stale — refundable'
        : 'Pending'

  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ border: '1px solid var(--border)' }}
    >
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center justify-between px-3.5 py-3 text-left"
        style={{ background: 'var(--surface)' }}
      >
        <div className="flex items-center gap-2.5">
          <FileText className="size-3.5 shrink-0" style={{ color: 'var(--accent)' }} />
          <span className="text-sm font-medium" style={{ color: 'var(--ink-2)' }}>
            Report #{String(reportId)}
          </span>
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
            {paidAtDate.toLocaleDateString()}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold" style={{ color: statusColor }}>
            {statusLabel}
          </span>
          {expanded ? (
            <ChevronUp className="size-3.5" style={{ color: 'var(--subtle)' }} />
          ) : (
            <ChevronDown className="size-3.5" style={{ color: 'var(--subtle)' }} />
          )}
        </div>
      </button>

      {expanded && (
        <div
          className="px-3.5 py-3 space-y-2 text-xs"
          style={{ background: 'var(--surface-muted)', borderTop: '1px solid var(--border)' }}
        >
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div style={{ color: 'var(--subtle)' }}>Fee paid</div>
              <div className="mono tabular-nums mt-0.5" style={{ color: 'var(--ink-2)' }}>
                {(Number(report.fee) / 1_000_000).toFixed(2)} USDC
              </div>
            </div>
            <div>
              <div style={{ color: 'var(--subtle)' }}>Paid at</div>
              <div className="mono mt-0.5" style={{ color: 'var(--ink-2)' }}>
                {paidAtDate.toLocaleTimeString()}
              </div>
            </div>
          </div>

          {isPending && (
            <div className="flex items-center gap-1.5" style={{ color: 'var(--subtle)' }}>
              <Clock className="size-3" />
              <span>
                {canRefund
                  ? 'Refund window open. Use Refund button if unpublished.'
                  : `Publish window closes at ${refundAt.toLocaleTimeString()}`}
              </span>
            </div>
          )}

          {isPublished && (
            <div>
              <div style={{ color: 'var(--subtle)' }}>Content hash</div>
              <div className="mono break-all mt-0.5" style={{ color: 'var(--muted)' }}>
                {report.contentHash}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

interface Props {
  address: `0x${string}`
}

export function ReportHistory({ address }: Props) {
  const { data: ids } = useReadContract({
    address: REPORT_DESK_ADDRESS,
    abi: REPORT_DESK_ABI,
    functionName: 'myReports',
    args: [address],
    chainId: CHAIN_ID,
  }) as { data: bigint[] | undefined }

  if (!ids || ids.length === 0) {
    return (
      <div
        className="rounded-2xl p-4 text-center"
        style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
      >
        <p className="text-sm" style={{ color: 'var(--subtle)' }}>
          No reports yet. Buy your first note above.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {[...ids].reverse().map((id) => (
        <ReportRow key={String(id)} reportId={id} />
      ))}
    </div>
  )
}
