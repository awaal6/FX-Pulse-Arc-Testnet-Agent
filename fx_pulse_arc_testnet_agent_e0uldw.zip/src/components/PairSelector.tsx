import { PAIRS, type Pair } from '../analyst'

interface Props {
  selected: Pair
  onChange: (pair: Pair) => void
  disabled?: boolean
}

const LABELS: Record<Pair, string> = {
  'USDC/EURC': 'USDC / EURC',
  'USDC/GBPA': 'USDC / GBPA',
  'USDC/JPYC': 'USDC / JPYC',
}

export function PairSelector({ selected, onChange, disabled }: Props) {
  return (
    <div className="flex gap-2">
      {PAIRS.map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          disabled={disabled}
          style={{
            background: selected === p ? 'var(--accent)' : 'var(--surface)',
            color: selected === p ? '#0d1b2f' : 'var(--ink-2)',
            border: `1px solid ${selected === p ? 'var(--accent)' : 'var(--border)'}`,
          }}
          className="flex-1 rounded-xl py-2.5 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
        >
          {LABELS[p]}
        </button>
      ))}
    </div>
  )
}
