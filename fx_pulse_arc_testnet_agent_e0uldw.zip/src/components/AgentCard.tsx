import { ExternalLink, Bot, AlertTriangle } from 'lucide-react'
import { useReadContract } from 'wagmi'
import { REPORT_DESK_ADDRESS, REPORT_DESK_ABI } from '../contracts'
import { buildAddressExplorerUrl } from '@/onchain-facts'

const CHAIN_ID = 5042002

interface Props {
  agentTokenId: bigint | undefined
}

export function AgentCard({ agentTokenId }: Props) {
  const { data: fee } = useReadContract({
    address: REPORT_DESK_ADDRESS,
    abi: REPORT_DESK_ABI,
    functionName: 'fee',
    chainId: CHAIN_ID,
  })

  return (
    <div
      className="rounded-2xl p-4 space-y-3"
      style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
    >
      <div className="flex items-center gap-2">
        <div
          className="flex size-7 items-center justify-center rounded-lg"
          style={{ background: 'rgba(172,198,233,0.15)' }}
        >
          <Bot className="size-4" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
            FX Pulse Agent
          </div>
          <div className="text-xs" style={{ color: 'var(--subtle)' }}>
            ERC-8004 Trustless Agent
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-lg p-2.5" style={{ background: 'var(--surface-muted)' }}>
          <div style={{ color: 'var(--subtle)' }}>Token ID</div>
          <div className="mono font-medium mt-0.5 tabular-nums" style={{ color: 'var(--ink-2)' }}>
            {agentTokenId != null ? String(agentTokenId) : '—'}
          </div>
        </div>
        <div className="rounded-lg p-2.5" style={{ background: 'var(--surface-muted)' }}>
          <div style={{ color: 'var(--subtle)' }}>Report fee</div>
          <div className="mono font-medium mt-0.5 tabular-nums" style={{ color: 'var(--ink-2)' }}>
            {fee != null ? `${(Number(fee) / 1_000_000).toFixed(2)} USDC` : '0.50 USDC'}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-1 text-xs">
        <a
          href={buildAddressExplorerUrl(CHAIN_ID, REPORT_DESK_ADDRESS)}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1"
          style={{ color: 'var(--accent)' }}
        >
          ReportDesk contract <ExternalLink className="size-3" />
        </a>
        <a
          href="https://explorer.testnet.arc.io/address/0x8004A818BFB912233c491871b3d84c89A494BD9e"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1"
          style={{ color: 'var(--accent)' }}
        >
          ERC-8004 IdentityRegistry <ExternalLink className="size-3" />
        </a>
      </div>

      {/* Not advice banner */}
      <div
        className="flex items-start gap-2 rounded-xl p-2.5"
        style={{ background: 'rgba(232,109,122,0.08)', border: '1px solid rgba(232,109,122,0.2)' }}
      >
        <AlertTriangle className="size-3.5 shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
        <span className="text-xs leading-relaxed" style={{ color: 'var(--danger)', opacity: 0.85 }}>
          Research only. This agent does not swap, trade, or hold user funds beyond the report fee. Not financial advice.
        </span>
      </div>
    </div>
  )
}
