import { ExternalLink, TrendingUp, TrendingDown, Minus, AlertTriangle } from 'lucide-react'
import type { FXNote } from '../analyst'
import { buildTxExplorerUrl } from '@/onchain-facts'

interface Props {
  note: FXNote
  reportId: bigint
  contentHash: `0x${string}`
  publishTxHash?: string
  chainId: number
}

const BIAS_CONFIG = {
  long_base: {
    label: 'Long Base',
    icon: TrendingUp,
    color: 'var(--success)',
    bg: 'rgba(141,216,159,0.12)',
  },
  long_quote: {
    label: 'Long Quote',
    icon: TrendingDown,
    color: 'var(--danger)',
    bg: 'rgba(232,109,122,0.12)',
  },
  neutral: {
    label: 'Neutral',
    icon: Minus,
    color: 'var(--muted)',
    bg: 'rgba(203,213,225,0.10)',
  },
}

export function NoteCard({ note, reportId, contentHash, publishTxHash, chainId }: Props) {
  const bias = BIAS_CONFIG[note.bias]
  const BiasIcon = bias.icon

  return (
    <div
      className="rounded-2xl p-5 space-y-4"
      style={{
        background: 'var(--surface-strong)',
        border: '1px solid var(--border)',
        backdropFilter: 'blur(20px)',
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
            {note.pair}
          </div>
          <div className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
            Report #{String(reportId)} · {note.horizon} horizon
          </div>
        </div>
        <div
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5"
          style={{ background: bias.bg }}
        >
          <BiasIcon className="size-3.5" style={{ color: bias.color }} />
          <span className="text-xs font-semibold" style={{ color: bias.color }}>
            {bias.label}
          </span>
        </div>
      </div>

      {/* Confidence bar */}
      <div>
        <div className="flex justify-between text-xs mb-1.5">
          <span style={{ color: 'var(--muted)' }}>Confidence</span>
          <span className="tabular-nums font-semibold" style={{ color: 'var(--ink-2)' }}>
            {note.confidence}%
          </span>
        </div>
        <div className="h-1.5 rounded-full" style={{ background: 'var(--surface-muted)' }}>
          <div
            className="h-1.5 rounded-full transition-all"
            style={{
              width: `${note.confidence}%`,
              background: `linear-gradient(90deg, var(--accent) 0%, var(--accent-hover) 100%)`,
            }}
          />
        </div>
      </div>

      {/* Mid price */}
      {note.mid != null && (
        <div className="flex items-baseline gap-2">
          <span className="display text-2xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
            {note.mid.toFixed(5)}
          </span>
          {note.change24hPct != null && (
            <span
              className="text-sm font-semibold tabular-nums"
              style={{ color: note.change24hPct >= 0 ? 'var(--success)' : 'var(--danger)' }}
            >
              {note.change24hPct >= 0 ? '+' : ''}
              {note.change24hPct.toFixed(3)}%
            </span>
          )}
        </div>
      )}

      {/* Drivers */}
      <div className="space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--subtle)' }}>
          Key Drivers
        </div>
        {note.drivers.map((d, i) => (
          <div key={i} className="flex gap-2.5">
            <div
              className="mt-1 size-1.5 shrink-0 rounded-full"
              style={{ background: 'var(--accent)' }}
            />
            <p className="text-sm leading-relaxed" style={{ color: 'var(--ink-2)' }}>
              {d}
            </p>
          </div>
        ))}
      </div>

      {/* Hash */}
      <div
        className="rounded-xl p-3 space-y-1"
        style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}
      >
        <div className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--subtle)' }}>
          Content Hash
        </div>
        <div className="mono text-xs break-all" style={{ color: 'var(--muted)' }}>
          {contentHash}
        </div>
        {publishTxHash && (
          <a
            href={buildTxExplorerUrl(chainId, publishTxHash)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs mt-1"
            style={{ color: 'var(--accent)' }}
          >
            View on ArcScan <ExternalLink className="size-3" />
          </a>
        )}
      </div>

      {/* Stub notice */}
      {note.isStub && (
        <div
          className="flex items-start gap-2 rounded-xl p-3"
          style={{ background: 'rgba(172,198,233,0.08)', border: '1px solid var(--border)' }}
        >
          <AlertTriangle className="size-3.5 shrink-0 mt-0.5" style={{ color: 'var(--accent)' }} />
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
            Using stub feed. Set VITE_PRICE_API_URL to enable live prices.
          </span>
        </div>
      )}

      {/* Disclaimer */}
      <p className="text-xs leading-relaxed" style={{ color: 'var(--subtle)' }}>
        {note.disclaimer}
      </p>

      <div className="text-xs" style={{ color: 'var(--subtle)', opacity: 0.6 }}>
        Generated {new Date(note.generatedAt).toLocaleTimeString()}
      </div>
    </div>
  )
}
