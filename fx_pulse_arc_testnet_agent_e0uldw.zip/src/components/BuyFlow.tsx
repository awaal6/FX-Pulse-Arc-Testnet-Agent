import { useState, useCallback } from 'react'
import {
  useAccount,
  useReadContract,
  useWriteContract,
  useWaitForTransactionReceipt,
  useSwitchChain,
} from 'wagmi'
import { erc20Abi, keccak256, toBytes } from 'viem'
import { Loader2, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'

import { REPORT_DESK_ADDRESS, REPORT_DESK_ABI } from '../contracts'
import { getUsdc } from '@/onchain-facts'
import { Amount, usdcDecimalsFor } from '@/onchain-money'
import { generateNote, canonicalJson, type FXNote, type Pair } from '../analyst'
import { PairSelector } from './PairSelector'
import { NoteCard } from './NoteCard'

const CHAIN_ID = 5042002
const FEE = 500_000n // 0.50 USDC (6 dec)

const usdc = getUsdc(CHAIN_ID)!
const USDC_ADDRESS = usdc.address as `0x${string}`

type FlowStep =
  | 'idle'
  | 'approving'
  | 'approve-confirming'
  | 'buying'
  | 'buy-confirming'
  | 'generating'
  | 'publishing'
  | 'publish-confirming'
  | 'done'
  | 'error'

interface Props {
  onReportBought: () => void
}

export function BuyFlow({ onReportBought }: Props) {
  const { address, chainId: walletChainId } = useAccount()
  const { switchChain } = useSwitchChain()

  const [selectedPair, setSelectedPair] = useState<Pair>('USDC/EURC')
  const [step, setStep] = useState<FlowStep>('idle')
  const [note, setNote] = useState<FXNote | null>(null)
  const [reportId, setReportId] = useState<bigint | null>(null)
  const [publishedHash, setPublishedHash] = useState<`0x${string}` | null>(null)
  const [publishTxHash, setPublishTxHash] = useState<string | undefined>()
  const [errorMsg, setErrorMsg] = useState('')

  const wrongChain = walletChainId !== CHAIN_ID

  // USDC balance
  const { data: usdcBalance, refetch: refetchBalance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address },
  })

  const formattedBalance =
    usdcBalance != null
      ? Amount.fromRaw(usdcBalance, usdcDecimalsFor(CHAIN_ID)).toFixed(2)
      : null

  // Current allowance
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address ? [address, REPORT_DESK_ADDRESS] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address },
  })

  // Write hooks
  const {
    writeContractAsync: approve,
    data: approveTxHash,
  } = useWriteContract()

  useWaitForTransactionReceipt({ hash: approveTxHash })

  const {
    writeContractAsync: buy,
    data: buyTxHash,
  } = useWriteContract()

  useWaitForTransactionReceipt({ hash: buyTxHash })

  const {
    writeContractAsync: publishReport,
    data: pubTxHash,
  } = useWriteContract()

  useWaitForTransactionReceipt({ hash: pubTxHash })

  const parseOnchainError = (error: unknown): string => {
    const msg = (error as Error)?.message?.toLowerCase() ?? ''
    if (msg.includes('user rejected') || msg.includes('4001'))
      return 'Transaction cancelled.'
    if (msg.includes('insufficient funds') || msg.includes('exceeds balance'))
      return 'Insufficient balance.'
    if (msg.includes('reverted')) return 'Transaction reverted. Check balance and allowance.'
    if (msg.includes('network') || msg.includes('timeout'))
      return 'Network issue. Please retry.'
    return 'Something went wrong. Please retry.'
  }

  const reset = useCallback(() => {
    setStep('idle')
    setNote(null)
    setReportId(null)
    setPublishedHash(null)
    setPublishTxHash(undefined)
    setErrorMsg('')
  }, [])

  const handleBuy = useCallback(async () => {
    if (!address) return
    if (wrongChain) {
      switchChain({ chainId: CHAIN_ID })
      return
    }

    try {
      const needsApproval = !allowance || allowance < FEE

      // Step 1: Approve if needed
      if (needsApproval) {
        setStep('approving')
        await approve({
          address: USDC_ADDRESS,
          abi: erc20Abi,
          functionName: 'approve',
          args: [REPORT_DESK_ADDRESS, FEE],
          chainId: CHAIN_ID,
        })
        setStep('approve-confirming')
        // Wait is tracked by hook, but we proceed after the next click
        // Re-fetch and continue
        await refetchAllowance()
      }

      // Step 2: Buy
      setStep('buying')
      const pairBytes = keccak256(toBytes(selectedPair))
      const buyHash = await buy({
        address: REPORT_DESK_ADDRESS,
        abi: REPORT_DESK_ABI,
        functionName: 'buyReport',
        args: [pairBytes],
        chainId: CHAIN_ID,
      })

      setStep('buy-confirming')

      // Wait for confirmation — parse reportId from logs
      // We use the receipt that wagmi's hook provides, but we do it manually here
      // to get the reportId synchronously
      const { createPublicClient, http, parseEventLogs } = await import('viem')
      const { requireChain } = await import('@/onchain-facts')
      const chain = requireChain(CHAIN_ID)
      // Build a minimal viem chain object
      const viemChain = {
        id: CHAIN_ID,
        name: chain.name,
        nativeCurrency: { name: 'USDC', symbol: 'USDC', decimals: 18 },
        rpcUrls: { default: { http: chain.rpcUrls } },
      } as const

      const publicClient = createPublicClient({
        chain: viemChain,
        transport: http(chain.rpcUrls[0]),
      })

      const receipt = await publicClient.waitForTransactionReceipt({ hash: buyHash })

      const logs = parseEventLogs({
        abi: REPORT_DESK_ABI,
        eventName: 'ReportPaid',
        logs: receipt.logs,
      })

      const firstLog = logs[0]
      const argsObj = firstLog?.args as Record<string, unknown> | undefined
      const parsedId: bigint = typeof argsObj?.reportId === 'bigint' ? argsObj.reportId : 0n
      setReportId(parsedId)

      // Step 3: Generate note
      setStep('generating')
      const generatedNote = await generateNote(selectedPair)
      setNote(generatedNote)

      // Step 4: Publish
      const canonical = canonicalJson(generatedNote)
      const contentHash = keccak256(toBytes(canonical))
      setPublishedHash(contentHash)

      setStep('publishing')
      const pubHash = await publishReport({
        address: REPORT_DESK_ADDRESS,
        abi: REPORT_DESK_ABI,
        functionName: 'publishReport',
        args: [parsedId, contentHash],
        chainId: CHAIN_ID,
      })

      setStep('publish-confirming')
      await publicClient.waitForTransactionReceipt({ hash: pubHash })
      setPublishTxHash(pubHash)

      setStep('done')
      await refetchBalance()
      onReportBought()
      toast.success('Report published onchain!')
    } catch (err: unknown) {
      const msg = parseOnchainError(err)
      setErrorMsg(msg)
      setStep('error')
      if (!msg.includes('cancelled')) {
        toast.error(msg)
      }
    }
  }, [
    address,
    wrongChain,
    switchChain,
    allowance,
    approve,
    buy,
    publishReport,
    selectedPair,
    refetchAllowance,
    refetchBalance,
    onReportBought,
  ])

  const isProcessing = [
    'approving',
    'approve-confirming',
    'buying',
    'buy-confirming',
    'generating',
    'publishing',
    'publish-confirming',
  ].includes(step)

  const stepLabel = {
    idle: wrongChain ? 'Switch to Arc Testnet' : !address ? 'Connect Wallet' : 'Approve 0.50 USDC + Buy Note',
    approving: 'Confirm approve in wallet…',
    'approve-confirming': 'Confirming approval…',
    buying: 'Confirm purchase in wallet…',
    'buy-confirming': 'Confirming purchase…',
    generating: 'Generating FX note…',
    publishing: 'Confirm publish in wallet…',
    'publish-confirming': 'Publishing onchain…',
    done: 'Buy Another Note',
    error: 'Retry',
  }[step]

  return (
    <div className="space-y-4">
      {/* Pair selector */}
      <PairSelector
        selected={selectedPair}
        onChange={(p) => {
          setSelectedPair(p)
          if (step === 'done' || step === 'error') reset()
        }}
        disabled={isProcessing}
      />

      {/* Balance strip */}
      {address && (
        <div
          className="flex items-center justify-between rounded-xl px-3.5 py-2.5"
          style={{ background: 'var(--surface-muted)' }}
        >
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
            Your USDC balance
          </span>
          <span
            className="tabular-nums text-sm font-semibold mono"
            style={{ color: 'var(--ink-2)' }}
          >
            {formattedBalance != null ? `${formattedBalance} USDC` : '—'}
          </span>
        </div>
      )}

      {/* Step progress */}
      {isProcessing && (
        <div
          className="flex items-center gap-2 rounded-xl px-3.5 py-2.5"
          style={{ background: 'rgba(172,198,233,0.08)', border: '1px solid var(--border)' }}
        >
          <Loader2 className="size-3.5 animate-spin shrink-0" style={{ color: 'var(--accent)' }} />
          <span className="text-xs" style={{ color: 'var(--accent)' }}>
            {stepLabel}
          </span>
        </div>
      )}

      {/* Error */}
      {step === 'error' && errorMsg && (
        <div
          className="rounded-xl px-3.5 py-2.5 text-xs"
          style={{
            background: 'rgba(232,109,122,0.08)',
            border: '1px solid rgba(232,109,122,0.25)',
            color: 'var(--danger)',
          }}
        >
          {errorMsg}
        </div>
      )}

      {/* CTA */}
      <button
        disabled={isProcessing || !address}
        onClick={step === 'done' || step === 'error' ? reset : handleBuy}
        className="w-full rounded-2xl py-3.5 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40 flex items-center justify-center gap-2"
        style={{ background: 'var(--accent)', color: '#0d1b2f' }}
      >
        {isProcessing && <Loader2 className="size-4 animate-spin" />}
        {step === 'done' && <RefreshCw className="size-4" />}
        {step === 'done' ? 'Buy Another Note' : step === 'error' ? 'Retry' : wrongChain ? 'Switch to Arc Testnet' : !address ? 'Connect Wallet' : isProcessing ? stepLabel : 'Approve 0.50 USDC + Buy Note'}
      </button>

      {/* Preview fee */}
      {step === 'idle' && (
        <p className="text-xs text-center" style={{ color: 'var(--subtle)', opacity: 0.7 }}>
          0.50 USDC · report delivered and published onchain in one flow
        </p>
      )}

      {/* Done: show note card */}
      {step === 'done' && note && reportId != null && publishedHash && (
        <NoteCard
          note={note}
          reportId={reportId}
          contentHash={publishedHash}
          publishTxHash={publishTxHash}
          chainId={CHAIN_ID}
        />
      )}
    </div>
  )
}
