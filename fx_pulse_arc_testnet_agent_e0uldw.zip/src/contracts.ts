// FX Pulse — ReportDesk contract config
// Arc Testnet (chainId 5042002)
// Mainnet ReportDesk: deploy manually (see README). Never auto-deployed by Arc Studio.

import artifact from '../contracts/out/ReportDesk.sol/ReportDesk.json'

export const REPORT_DESK_ADDRESS =
  '0xb88ce5fb990b8c47fa5edfe2f4aed36ba7d4db7b' as const

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const REPORT_DESK_ABI = artifact.abi as any[]
