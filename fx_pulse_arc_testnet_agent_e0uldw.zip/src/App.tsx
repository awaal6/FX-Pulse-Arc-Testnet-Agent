import { useState, useCallback } from 'react'
import { useAccount, useReadContract } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { Newspaper, History, Bot, ExternalLink } from 'lucide-react'

import { REPORT_DESK_ADDRESS, REPORT_DESK_ABI } from './contracts'
import { BuyFlow } from './components/BuyFlow'
import { AgentCard } from './components/AgentCard'
import { ReportHistory } from './components/ReportHistory'

const CHAIN_ID = 5042002

type Tab = 'buy' | 'history' | 'agent'

export default function App() {
  const { address } = useAccount()
  const [tab, setTab] = useState<Tab>('buy')
  const [historyKey, setHistoryKey] = useState(0)

  const { data: agentTokenId } = useReadContract({
    address: REPORT_DESK_ADDRESS,
    abi: REPORT_DESK_ABI,
    functionName: 'agentTokenId',
    chainId: CHAIN_ID,
  }) as { data: bigint | undefined }

  const handleReportBought = useCallback(() => {
    setHistoryKey((k) => k + 1)
  }, [])

  const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'buy', label: 'Buy Note', icon: Newspaper },
    { id: 'history', label: 'History', icon: History },
    { id: 'agent', label: 'Agent', icon: Bot },
  ]

  return (
    <div
      className="min-h-dvh flex flex-col"
      style={{ background: 'var(--bg-gradient)' }}
    >
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-4 py-3.5"
        style={{
          background: 'rgba(13,27,47,0.85)',
          backdropFilter: 'blur(16px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <img
          src="/fx-pulse-logo.svg"
          alt="FX Pulse"
          className="h-10 w-auto"
          style={{ imageRendering: 'crisp-edges' }}
        />
        <ConnectKitButton />
      </header>

      {/* Main */}
      <main className="flex-1 flex justify-center px-4 py-6">
        <div className="w-full max-w-md space-y-4">
          {/* Tabs */}
          <div
            className="flex rounded-2xl p-1 gap-1"
            style={{ background: 'var(--surface-muted)' }}
          >
            {TABS.map((t) => {
              const Icon = t.icon
              const active = tab === t.id
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  style={{
                    background: active ? 'var(--surface-strong)' : 'transparent',
                    color: active ? 'var(--ink)' : 'var(--subtle)',
                    border: active ? '1px solid var(--border)' : '1px solid transparent',
                  }}
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-semibold transition-all"
                >
                  <Icon className="size-3.5" />
                  {t.label}
                </button>
              )
            })}
          </div>

          {/* Tab content */}
          {tab === 'buy' && (
            <div
              className="rounded-2xl p-5 space-y-5"
              style={{
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                backdropFilter: 'blur(20px)',
              }}
            >
              <div>
                <h2 className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>
                  Buy an FX Note
                </h2>
                <p className="text-xs mt-1" style={{ color: 'var(--subtle)' }}>
                  Pay 0.50 USDC · receive a signed research note onchain
                </p>
              </div>
              <BuyFlow onReportBought={handleReportBought} />
            </div>
          )}

          {tab === 'history' && (
            <div className="space-y-3">
              <div className="px-1">
                <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
                  Report History
                </h2>
                <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
                  {address ? 'Your paid reports on this wallet.' : 'Connect your wallet to view history.'}
                </p>
              </div>
              {address ? (
                <ReportHistory key={historyKey} address={address} />
              ) : (
                <div
                  className="rounded-2xl p-6 text-center"
                  style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
                >
                  <p className="text-sm" style={{ color: 'var(--subtle)' }}>
                    Connect your wallet to see your reports.
                  </p>
                </div>
              )}
            </div>
          )}

          {tab === 'agent' && (
            <div className="space-y-3">
              <div className="px-1">
                <h2 className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>
                  Agent Identity
                </h2>
                <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
                  ERC-8004 registered agent on Arc Testnet.
                </p>
              </div>
              <AgentCard agentTokenId={agentTokenId} />
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer
        className="px-4 py-4 text-center space-y-1"
        style={{ borderTop: '1px solid var(--border)' }}
      >
        <p className="text-xs" style={{ color: 'var(--subtle)', opacity: 0.6 }}>
          Testnet only. Not financial advice. Contract addresses are Arc Testnet.
        </p>
        <p className="text-xs" style={{ color: 'var(--subtle)', opacity: 0.4 }}>
          Mainnet deploy is manual — see README.
        </p>
        <div className="flex items-center justify-center gap-3 mt-1">
          <a
            href="https://explorer.testnet.arc.io/address/0xb88ce5fb990b8c47fa5edfe2f4aed36ba7d4db7b"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs"
            style={{ color: 'var(--accent)', opacity: 0.7 }}
          >
            ReportDesk <ExternalLink className="size-2.5" />
          </a>
          <a
            href="/agent.json"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs"
            style={{ color: 'var(--accent)', opacity: 0.7 }}
          >
            Agent Card <ExternalLink className="size-2.5" />
          </a>
        </div>
      </footer>
    </div>
  )
}
