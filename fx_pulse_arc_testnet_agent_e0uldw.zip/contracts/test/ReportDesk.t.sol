// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReportDesk} from "../ReportDesk.sol";

// ---------------------------------------------------------------------------
// Minimal mock USDC — 6 decimals, mint helper, full ERC-20
// ---------------------------------------------------------------------------
contract MockUSDC is ERC20 {
    constructor() ERC20("Mock USDC", "mUSDC") {}

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}

// ---------------------------------------------------------------------------
// Malicious reentrant buyer — tries to call refundIfStale from inside
// transferFrom to test the nonReentrant guard.
// ---------------------------------------------------------------------------
contract ReentrantBuyer {
    ReportDesk public desk;
    MockUSDC public usdc;
    bytes32 public constant PAIR = keccak256("REENTRANT/TEST");
    uint256 public attackReportId;
    bool public attacking;

    constructor(address _desk, address _usdc) {
        desk = ReportDesk(_desk);
        usdc = MockUSDC(_usdc);
    }

    // Approve max and buy — `transferFrom` is called inside buyReport.
    // We hook the transfer callback via a fake token, but here we test the
    // simpler path: attempt direct re-entry via a second buyReport call.
    function attack() external {
        attacking = true;
        usdc.approve(address(desk), type(uint256).max);
        attackReportId = desk.buyReport(PAIR);
        attacking = false;
    }
}

// ---------------------------------------------------------------------------
// Main test contract
// ---------------------------------------------------------------------------
contract ReportDeskTest is Test {
    // Mirror events from the contract for expectEmit
    event ReportPaid(uint256 indexed reportId, address indexed buyer, bytes32 indexed pairId, uint256 amount);
    event ReportPublished(uint256 indexed reportId, bytes32 contentHash);
    event AgentRegistered(uint256 indexed tokenId);
    event Refunded(uint256 indexed reportId, address indexed buyer, uint256 amount);

    ReportDesk internal desk;
    MockUSDC internal usdc;

    address internal owner = makeAddr("owner");
    address internal alice  = makeAddr("alice");
    address internal bob    = makeAddr("bob");
    address internal carol  = makeAddr("carol");

    // Hardcoded identity registry address – only needs to be non-zero for constructor.
    address internal constant ID_REGISTRY = 0x8004A818BFB912233c491871b3d84c89A494BD9e;

    bytes32 internal constant PAIR_A = keccak256("USDC/EURC");
    bytes32 internal constant PAIR_B = keccak256("USDC/USDT");
    uint256 internal constant FEE    = 500_000; // 0.50 USDC (6 decimals)

    // Seed each buyer with 10 USDC and infinite approval
    function _fundAndApprove(address who, uint256 amount) internal {
        usdc.mint(who, amount);
        vm.prank(who);
        usdc.approve(address(desk), type(uint256).max);
    }

    function setUp() public {
        usdc = new MockUSDC();
        desk = new ReportDesk(owner, address(usdc), ID_REGISTRY);

        _fundAndApprove(alice, 10_000_000); // 10 USDC
        _fundAndApprove(bob,   10_000_000);
        _fundAndApprove(carol, 10_000_000);
    }

    // =========================================================================
    // 1. Deployment & initialization
    // =========================================================================

    function test_Constructor_StoresImmutables() public view {
        assertEq(desk.USDC(),              address(usdc));
        assertEq(desk.IDENTITY_REGISTRY(), ID_REGISTRY);
        assertEq(desk.owner(),             owner);
        assertEq(desk.agentTokenId(),      0);
    }

    function test_Constructor_RevertOnZeroUSDC() public {
        vm.expectRevert("USDC is zero");
        new ReportDesk(owner, address(0), ID_REGISTRY);
    }

    function test_Constructor_RevertOnZeroIdentityRegistry() public {
        vm.expectRevert("Identity registry is zero");
        new ReportDesk(owner, address(usdc), address(0));
    }

    function test_FeeConstantMatchesPublicGetter() public view {
        assertEq(desk.fee(), FEE);
        assertEq(desk.FEE(), FEE);
    }

    // =========================================================================
    // 2. setAgentTokenId
    // =========================================================================

    function test_SetAgentTokenId_HappyPath() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(desk));
        emit AgentRegistered(42);
        desk.setAgentTokenId(42);

        assertEq(desk.agentTokenId(), 42);
    }

    function test_SetAgentTokenId_RevertIfNotOwner() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice));
        desk.setAgentTokenId(1);
    }

    function test_SetAgentTokenId_RevertIfZero() public {
        vm.prank(owner);
        vm.expectRevert("TokenId is zero");
        desk.setAgentTokenId(0);
    }

    function test_SetAgentTokenId_RevertIfAlreadySet() public {
        vm.prank(owner);
        desk.setAgentTokenId(1);

        vm.prank(owner);
        vm.expectRevert("Agent token already set");
        desk.setAgentTokenId(2);
    }

    // =========================================================================
    // 3. buyReport — happy path
    // =========================================================================

    function test_BuyReport_HappyPath_ReturnsId() public {
        vm.prank(alice);
        vm.expectEmit(true, true, true, true, address(desk));
        emit ReportPaid(0, alice, PAIR_A, FEE);
        uint256 id = desk.buyReport(PAIR_A);

        assertEq(id, 0);
    }

    function test_BuyReport_StoresBuyerState() public {
        uint256 ts = block.timestamp;
        vm.prank(alice);
        desk.buyReport(PAIR_A);

        ReportDesk.Report memory r = desk.getReport(0);
        assertEq(r.reportId,    0);
        assertEq(r.buyer,       alice);
        assertEq(r.pairId,      PAIR_A);
        assertEq(r.paidAt,      ts);
        assertEq(r.fee,         FEE);
        assertEq(r.contentHash, bytes32(0));
        assertFalse(r.published);
    }

    function test_BuyReport_DeductsFeeFromBuyer() public {
        uint256 before = usdc.balanceOf(alice);
        vm.prank(alice);
        desk.buyReport(PAIR_A);
        assertEq(usdc.balanceOf(alice), before - FEE);
    }

    function test_BuyReport_CreditsDeskBalance() public {
        vm.prank(alice);
        desk.buyReport(PAIR_A);
        assertEq(usdc.balanceOf(address(desk)), FEE);
    }

    function test_BuyReport_IncrementsPendingFees() public {
        assertEq(desk.pendingFees(), 0);
        vm.prank(alice);
        desk.buyReport(PAIR_A);
        assertEq(desk.pendingFees(), FEE);
        vm.prank(bob);
        desk.buyReport(PAIR_B);
        assertEq(desk.pendingFees(), FEE * 2);
    }

    function test_BuyReport_TracksMyReports() public {
        vm.prank(alice);
        desk.buyReport(PAIR_A);
        vm.prank(alice);
        desk.buyReport(PAIR_B);

        uint256[] memory ids = desk.myReports(alice);
        assertEq(ids.length, 2);
        assertEq(ids[0], 0);
        assertEq(ids[1], 1);
    }

    function test_BuyReport_SequentialIdsAcrossBuyers() public {
        vm.prank(alice);
        uint256 id0 = desk.buyReport(PAIR_A);
        vm.prank(bob);
        uint256 id1 = desk.buyReport(PAIR_B);
        vm.prank(carol);
        uint256 id2 = desk.buyReport(PAIR_A);

        assertEq(id0, 0);
        assertEq(id1, 1);
        assertEq(id2, 2);
    }

    // =========================================================================
    // 4. buyReport — revert paths
    // =========================================================================

    function test_BuyReport_RevertOnZeroPairId() public {
        vm.prank(alice);
        vm.expectRevert("PairId is zero");
        desk.buyReport(bytes32(0));
    }

    function test_BuyReport_RevertOnInsufficientBalance() public {
        address broke = makeAddr("broke");
        // broke has 0 USDC, but infinite approval
        vm.prank(broke);
        usdc.approve(address(desk), type(uint256).max);

        vm.prank(broke);
        vm.expectRevert();
        desk.buyReport(PAIR_A);
    }

    function test_BuyReport_RevertOnInsufficientAllowance() public {
        address miser = makeAddr("miser");
        usdc.mint(miser, 1_000_000);
        vm.prank(miser);
        usdc.approve(address(desk), FEE - 1); // one short

        vm.prank(miser);
        vm.expectRevert();
        desk.buyReport(PAIR_A);
    }

    // =========================================================================
    // 5. publishReport — happy path
    // =========================================================================

    function test_PublishReport_HappyPath() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        bytes32 hash = keccak256("content");

        vm.prank(owner);
        vm.expectEmit(true, false, false, true, address(desk));
        emit ReportPublished(id, hash);
        desk.publishReport(id, hash);

        ReportDesk.Report memory r = desk.getReport(id);
        assertEq(r.contentHash, hash);
        assertTrue(r.published);
    }

    function test_PublishReport_DecreasesPendingFees() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);
        assertEq(desk.pendingFees(), FEE);

        vm.prank(owner);
        desk.publishReport(id, keccak256("content"));

        // Pending fees released — fee is now withdrawable.
        assertEq(desk.pendingFees(), 0);
    }

    // =========================================================================
    // 6. publishReport — revert paths
    // =========================================================================

    function test_PublishReport_RevertIfNotOwner() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, bob));
        desk.publishReport(id, keccak256("x"));
    }

    function test_PublishReport_RevertOnZeroContentHash() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.prank(owner);
        vm.expectRevert("Content hash is zero");
        desk.publishReport(id, bytes32(0));
    }

    function test_PublishReport_RevertOnNonExistentReport() public {
        vm.prank(owner);
        vm.expectRevert("Report does not exist");
        desk.publishReport(999, keccak256("x"));
    }

    function test_PublishReport_RevertOnDoublePublish() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.prank(owner);
        desk.publishReport(id, keccak256("first"));

        vm.prank(owner);
        vm.expectRevert("Already published");
        desk.publishReport(id, keccak256("second"));
    }

    /// @dev NEW — publish window: owner CANNOT publish at or after paidAt + 900s.
    function test_PublishReport_RevertAfterWindow_ExactBoundary() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);
        uint256 paidAt = block.timestamp;

        // Warp to EXACTLY the boundary (>= paidAt + 900).
        vm.warp(paidAt + 900);

        vm.prank(owner);
        vm.expectRevert("Publish window closed");
        desk.publishReport(id, keccak256("late"));
    }

    /// @dev NEW — publish window: owner CANNOT publish well past the window.
    function test_PublishReport_RevertWellAfterWindow() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);
        uint256 paidAt = block.timestamp;

        vm.warp(paidAt + 1 hours);

        vm.prank(owner);
        vm.expectRevert("Publish window closed");
        desk.publishReport(id, keccak256("toolate"));
    }

    /// @dev NEW — publish succeeds one second BEFORE the boundary.
    function test_PublishReport_SucceedsOneSecBeforeWindow() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);
        uint256 paidAt = block.timestamp;

        vm.warp(paidAt + 899);

        vm.prank(owner);
        desk.publishReport(id, keccak256("justintime")); // must not revert
        assertTrue(desk.getReport(id).published);
    }

    // =========================================================================
    // 7. refundIfStale — happy path
    // =========================================================================

    function test_RefundIfStale_HappyPath() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        uint256 balBefore = usdc.balanceOf(alice);

        vm.warp(block.timestamp + 900);

        vm.prank(alice);
        vm.expectEmit(true, true, false, true, address(desk));
        emit Refunded(id, alice, FEE);
        desk.refundIfStale(id);

        assertEq(usdc.balanceOf(alice), balBefore + FEE);

        ReportDesk.Report memory r = desk.getReport(id);
        assertTrue(r.published);
        assertEq(r.contentHash, bytes32(type(uint256).max));
    }

    function test_RefundIfStale_ExactBoundary() public {
        // At exactly paidAt + 900 the refund should succeed.
        uint256 paidAt = block.timestamp;
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.warp(paidAt + 900);

        vm.prank(alice);
        desk.refundIfStale(id); // must not revert
    }

    // =========================================================================
    // 8. refundIfStale — revert paths
    // =========================================================================

    function test_RefundIfStale_RevertTooEarly() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.warp(block.timestamp + 899); // one second short

        vm.prank(alice);
        vm.expectRevert("Too early for refund");
        desk.refundIfStale(id);
    }

    function test_RefundIfStale_RevertOnNonExistentReport() public {
        vm.prank(alice);
        vm.expectRevert("Report does not exist");
        desk.refundIfStale(999);
    }

    function test_RefundIfStale_RevertIfNotBuyer() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.warp(block.timestamp + 900);

        vm.prank(bob);
        vm.expectRevert("Not report buyer");
        desk.refundIfStale(id);
    }

    function test_RefundIfStale_RevertIfAlreadyPublished() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.prank(owner);
        desk.publishReport(id, keccak256("done"));

        vm.warp(block.timestamp + 900);

        vm.prank(alice);
        vm.expectRevert("Already finalized");
        desk.refundIfStale(id);
    }

    function test_RefundIfStale_CannotRefundTwice() public {
        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.warp(block.timestamp + 900);

        vm.prank(alice);
        desk.refundIfStale(id);

        // Second call: report is now "published" (finalized), should revert.
        vm.prank(alice);
        vm.expectRevert("Already finalized");
        desk.refundIfStale(id);
    }

    // =========================================================================
    // 9. withdrawFees
    // =========================================================================

    /// @dev NEW — withdrawFees only withdraws the NON-pending portion.
    ///      Scenario: buy 2, publish 1 → only 1 fee is withdrawable.
    function test_WithdrawFees_OnlyNonPendingPortion() public {
        vm.prank(alice);
        uint256 idA = desk.buyReport(PAIR_A);
        vm.prank(bob);
        desk.buyReport(PAIR_B); // id 1 stays pending

        // Publish only alice's report — releases its fee from pending.
        vm.prank(owner);
        desk.publishReport(idA, keccak256("hashA"));

        // Desk holds 2 × FEE; only 1 × FEE is withdrawable (bob's is still pending).
        assertEq(usdc.balanceOf(address(desk)), FEE * 2);
        assertEq(desk.pendingFees(),            FEE);

        address treasury = makeAddr("treasury");
        vm.prank(owner);
        desk.withdrawFees(treasury);

        // Treasury receives exactly 1 × FEE (alice's earned fee).
        assertEq(usdc.balanceOf(treasury),      FEE);
        // Desk still holds bob's pending fee.
        assertEq(usdc.balanceOf(address(desk)), FEE);
        assertEq(desk.pendingFees(),            FEE);
    }

    /// @dev NEW — withdrawFees reverts when everything in the balance is still pending.
    function test_WithdrawFees_RevertNothingToWithdraw_AllPending() public {
        vm.prank(alice);
        desk.buyReport(PAIR_A);
        // balance == FEE, pendingFees == FEE → withdrawable == 0

        address treasury = makeAddr("treasury");
        vm.prank(owner);
        vm.expectRevert("Nothing to withdraw");
        desk.withdrawFees(treasury);
    }

    /// @dev NEW — withdrawFees reverts on a completely empty desk.
    function test_WithdrawFees_RevertNothingToWithdraw_EmptyBalance() public {
        address treasury = makeAddr("treasury");
        vm.prank(owner);
        vm.expectRevert("Nothing to withdraw");
        desk.withdrawFees(treasury);
    }

    function test_WithdrawFees_RevertIfNotOwner() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice));
        desk.withdrawFees(alice);
    }

    function test_WithdrawFees_RevertOnZeroAddress() public {
        vm.prank(owner);
        vm.expectRevert("To is zero");
        desk.withdrawFees(address(0));
    }

    /// @dev Multiple publishes accumulate the withdrawable amount correctly.
    function test_WithdrawFees_AccumulatesAcrossMultiplePublishes() public {
        vm.prank(alice);
        uint256 idA = desk.buyReport(PAIR_A);
        vm.prank(bob);
        uint256 idB = desk.buyReport(PAIR_B);
        vm.prank(carol);
        desk.buyReport(PAIR_A); // id 2 — stays pending

        // Publish alice's and bob's reports.
        vm.prank(owner);
        desk.publishReport(idA, keccak256("hashA"));
        vm.prank(owner);
        desk.publishReport(idB, keccak256("hashB"));

        // 2 fees earned, 1 still pending.
        assertEq(desk.pendingFees(), FEE);

        address treasury = makeAddr("treasury");
        vm.prank(owner);
        desk.withdrawFees(treasury);

        assertEq(usdc.balanceOf(treasury),      FEE * 2);
        assertEq(usdc.balanceOf(address(desk)), FEE);      // carol's pending remains
        assertEq(desk.pendingFees(),            FEE);
    }

    /// @dev After refund, the pending fee is released; withdrawFees on a desk with
    ///      published fees still gets the correct (non-refunded) amount.
    function test_WithdrawFees_AfterMixedPublishAndRefund() public {
        vm.prank(alice);
        uint256 idA = desk.buyReport(PAIR_A); // published
        vm.prank(bob);
        uint256 idB = desk.buyReport(PAIR_B); // refunded
        vm.prank(carol);
        desk.buyReport(PAIR_A);               // id 2 — still pending

        // Publish alice's report.
        vm.prank(owner);
        desk.publishReport(idA, keccak256("hashA"));

        // Refund bob after window.
        vm.warp(block.timestamp + 900);
        vm.prank(bob);
        desk.refundIfStale(idB);

        // Desk balance = carol's pending FEE (alice's earned + bob's refund cancel out:
        //   started: 3*FEE, alice published but fee stays: 3*FEE,
        //   bob refunded: 3*FEE - FEE = 2*FEE; pendingFees = carol's FEE).
        assertEq(usdc.balanceOf(address(desk)), FEE * 2);
        assertEq(desk.pendingFees(),            FEE);

        address treasury = makeAddr("treasury");
        vm.prank(owner);
        desk.withdrawFees(treasury);

        // Only alice's earned FEE is withdrawable.
        assertEq(usdc.balanceOf(treasury),      FEE);
        assertEq(usdc.balanceOf(address(desk)), FEE); // carol's pending remains
    }

    // =========================================================================
    // 10. myReports view
    // =========================================================================

    function test_MyReports_EmptyForNewAddress() public {
        uint256[] memory ids = desk.myReports(makeAddr("stranger"));
        assertEq(ids.length, 0);
    }

    function test_MyReports_MultipleReportsPerBuyer() public {
        vm.prank(alice);
        desk.buyReport(PAIR_A);
        vm.prank(bob);
        desk.buyReport(PAIR_B);  // id 1 — owned by bob, not alice
        vm.prank(alice);
        desk.buyReport(PAIR_B);  // id 2 — alice's second

        uint256[] memory aliceIds = desk.myReports(alice);
        assertEq(aliceIds.length, 2);
        assertEq(aliceIds[0], 0);
        assertEq(aliceIds[1], 2);

        uint256[] memory bobIds = desk.myReports(bob);
        assertEq(bobIds.length, 1);
        assertEq(bobIds[0], 1);
    }

    // =========================================================================
    // 11. Fuzz tests
    // =========================================================================

    /// @dev Any non-zero pairId should produce a valid report.
    function testFuzz_BuyReport_AnyNonZeroPairId(bytes32 pairId) public {
        vm.assume(pairId != bytes32(0));

        vm.prank(alice);
        uint256 id = desk.buyReport(pairId);

        ReportDesk.Report memory r = desk.getReport(id);
        assertEq(r.pairId, pairId);
        assertEq(r.buyer,  alice);
        assertEq(r.fee,    FEE);
        assertFalse(r.published);
    }

    /// @dev Sequential report IDs must be strictly monotonic.
    function testFuzz_BuyReport_IdMonotonic(uint8 n) public {
        // Cap at 20 buys to stay within the alice funding cap (10 USDC = 20 × FEE).
        n = uint8(bound(n, 1, 20));

        for (uint256 i = 0; i < n; i++) {
            vm.prank(alice);
            uint256 id = desk.buyReport(PAIR_A);
            assertEq(id, i);
        }

        // Verify all reports are stored correctly.
        for (uint256 i = 0; i < n; i++) {
            assertEq(desk.getReport(i).buyer, alice);
        }
    }

    /// @dev publishReport accepts any non-zero content hash within the window.
    function testFuzz_PublishReport_AnyNonZeroHash(bytes32 hash) public {
        vm.assume(hash != bytes32(0));

        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        vm.prank(owner);
        desk.publishReport(id, hash);

        assertEq(desk.getReport(id).contentHash, hash);
        assertTrue(desk.getReport(id).published);
    }

    /// @dev NEW fuzz — publish window boundary: succeed before 900s, revert at or after.
    function testFuzz_PublishReport_WindowBoundary(uint256 warpSecs) public {
        warpSecs = bound(warpSecs, 0, 1_800);

        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        uint256 paidAt = block.timestamp;
        vm.warp(paidAt + warpSecs);

        if (warpSecs < 900) {
            vm.prank(owner);
            desk.publishReport(id, keccak256("ok")); // must succeed
            assertTrue(desk.getReport(id).published);
        } else {
            vm.prank(owner);
            vm.expectRevert("Publish window closed");
            desk.publishReport(id, keccak256("late"));
        }
    }

    /// @dev Refund window: any warp < 900s should revert; >= 900s should succeed.
    function testFuzz_RefundIfStale_TimeWindow(uint256 warpSecs) public {
        warpSecs = bound(warpSecs, 0, 1_800);

        vm.prank(alice);
        uint256 id = desk.buyReport(PAIR_A);

        uint256 paidAt = block.timestamp;
        vm.warp(paidAt + warpSecs);

        if (warpSecs < 900) {
            vm.prank(alice);
            vm.expectRevert("Too early for refund");
            desk.refundIfStale(id);
        } else {
            vm.prank(alice);
            desk.refundIfStale(id); // must succeed
            assertTrue(desk.getReport(id).published);
        }
    }

    // =========================================================================
    // 12. Scenario test: mixed buy/publish/refund/withdraw lifecycle
    // =========================================================================

    /// @dev Three buyers; one published, one refunded, one still pending.
    ///      Verifies the interplay of pendingFees and withdrawable amounts.
    function test_Lifecycle_PublishRefundPending() public {
        // --- buy ---
        vm.prank(alice);
        uint256 idA = desk.buyReport(PAIR_A); // will be published
        vm.prank(bob);
        uint256 idB = desk.buyReport(PAIR_B); // will be refunded
        vm.prank(carol);
        desk.buyReport(PAIR_A);               // will stay pending

        assertEq(usdc.balanceOf(address(desk)), FEE * 3);
        assertEq(desk.pendingFees(),            FEE * 3);

        // --- publish alice's report (within window) ---
        vm.prank(owner);
        desk.publishReport(idA, keccak256("hashA"));

        assertEq(desk.pendingFees(),            FEE * 2, "2 reports still pending after publish");
        assertEq(usdc.balanceOf(address(desk)), FEE * 3, "balance unchanged by publish");

        // --- withdraw alice's earned fee ---
        address treasury = makeAddr("treasury");
        vm.prank(owner);
        desk.withdrawFees(treasury);

        assertEq(usdc.balanceOf(treasury),      FEE,     "treasury receives 1 earned fee");
        assertEq(usdc.balanceOf(address(desk)), FEE * 2, "desk holds 2 pending fees");
        assertEq(desk.pendingFees(),            FEE * 2, "still 2 pending after withdraw");

        // --- refund bob after window ---
        vm.warp(block.timestamp + 900);
        vm.prank(bob);
        desk.refundIfStale(idB);

        assertEq(usdc.balanceOf(address(desk)), FEE,     "desk holds only carol's pending fee");
        assertEq(desk.pendingFees(),            FEE,     "carol's fee still pending");

        // --- nothing more to withdraw (only carol's pending remains) ---
        vm.prank(owner);
        vm.expectRevert("Nothing to withdraw");
        desk.withdrawFees(treasury);
    }

    // =========================================================================
    // 13. Invariant: balance - _pendingFees >= 0 and equals earned fees
    // =========================================================================

    /// @dev Stateful check: after every operation, the desk's USDC balance is always
    ///      >= pendingFees (i.e. withdrawable is never negative), and the withdrawable
    ///      portion equals exactly the sum of fees from published (non-refunded) reports.
    function test_Invariant_WithdrawableEqualsEarnedFees() public {
        // Setup: buy 3 reports.
        vm.prank(alice);
        uint256 idA = desk.buyReport(PAIR_A);
        vm.prank(bob);
        uint256 idB = desk.buyReport(PAIR_B);
        vm.prank(carol);
        uint256 idC = desk.buyReport(PAIR_A);

        // --- invariant after buys: nothing earned yet ---
        _assertInvariant(0, "after 3 buys");

        // Publish alice's.
        vm.prank(owner);
        desk.publishReport(idA, keccak256("hA"));
        _assertInvariant(FEE, "after 1 publish");

        // Publish bob's.
        vm.prank(owner);
        desk.publishReport(idB, keccak256("hB"));
        _assertInvariant(FEE * 2, "after 2 publishes");

        // Refund carol's (warp past window).
        vm.warp(block.timestamp + 900);
        vm.prank(carol);
        desk.refundIfStale(idC);
        // Refund removes from balance and from pending — earned still = 2 × FEE.
        _assertInvariant(FEE * 2, "after 1 refund");

        // Withdraw earned fees.
        address treasury = makeAddr("treasury");
        vm.prank(owner);
        desk.withdrawFees(treasury);

        // After withdraw: balance == 0, pendingFees == 0, earned == 0.
        assertEq(usdc.balanceOf(address(desk)), 0);
        assertEq(desk.pendingFees(),            0);
    }

    /// @dev Fuzz version: n buys, then publish some, refund the rest (after warp),
    ///      then assert the invariant holds throughout.
    function testFuzz_Invariant_BalanceMinusPendingEqualsEarned(
        uint8 nBuys,
        uint8 nPublish
    ) public {
        nBuys    = uint8(bound(nBuys,    1, 10));
        nPublish = uint8(bound(nPublish, 0, nBuys));

        // Ensure alice has enough.
        usdc.mint(alice, uint256(nBuys) * FEE);
        vm.prank(alice);
        usdc.approve(address(desk), type(uint256).max);

        uint256[] memory ids = new uint256[](nBuys);
        for (uint256 i = 0; i < nBuys; i++) {
            vm.prank(alice);
            ids[i] = desk.buyReport(PAIR_A);
        }

        // Invariant: balance == pendingFees (nothing earned yet).
        assertEq(
            usdc.balanceOf(address(desk)),
            desk.pendingFees(),
            "before publish: all pending"
        );

        // Publish nPublish of them (within window).
        for (uint256 i = 0; i < nPublish; i++) {
            vm.prank(owner);
            desk.publishReport(ids[i], keccak256(abi.encodePacked(i)));
        }

        uint256 expectedEarned = uint256(nPublish) * FEE;
        uint256 expectedPending = uint256(nBuys - nPublish) * FEE;

        // Core invariant: balance - pendingFees >= 0 and equals earned.
        uint256 bal = usdc.balanceOf(address(desk));
        uint256 pending = desk.pendingFees();

        assertGe(bal, pending, "balance always >= pendingFees");
        assertEq(bal - pending, expectedEarned, "withdrawable == earned fees");
        assertEq(pending, expectedPending, "pendingFees == unpublished report fees");

        // If there are earned fees, withdraw should succeed and drain them.
        if (expectedEarned > 0) {
            address treasury = makeAddr("treasury");
            vm.prank(owner);
            desk.withdrawFees(treasury);

            assertEq(usdc.balanceOf(treasury),      expectedEarned, "treasury gets earned fees");
            assertEq(usdc.balanceOf(address(desk)), expectedPending, "desk holds only pending");
            assertGe(usdc.balanceOf(address(desk)), desk.pendingFees(), "invariant holds post-withdraw");
        }
    }

    // =========================================================================
    // Internal helpers
    // =========================================================================

    /// @dev Assert that withdrawable (balance - pendingFees) equals `expectedEarned`,
    ///      and that balance >= pendingFees (no underflow possible).
    function _assertInvariant(uint256 expectedEarned, string memory label) internal view {
        uint256 bal     = usdc.balanceOf(address(desk));
        uint256 pending = desk.pendingFees();

        assertGe(bal, pending, string.concat("balance >= pendingFees [", label, "]"));
        assertEq(
            bal - pending,
            expectedEarned,
            string.concat("withdrawable == earned [", label, "]")
        );
    }
}
