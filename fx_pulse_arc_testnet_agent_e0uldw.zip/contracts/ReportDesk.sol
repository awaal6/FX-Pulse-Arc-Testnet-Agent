// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

interface IIdentityRegistry {
    function register(string calldata agentURI) external returns (uint256 agentId);
}

contract ReportDesk is Ownable, ReentrancyGuard {
    uint256 public constant FEE = 500_000; // 0.50 USDC (6 decimals)

    // Arc Testnet (chainId 5042002)
    // USDC (6 decimals): 0x3600000000000000000000000000000000000000
    // ERC-8004 IdentityRegistry (testnet): 0x8004A818BFB912233c491871b3d84c89A494BD9e
    // ERC-8004 IdentityRegistry (mainnet): 0x8004A169FB4a3325136EB29fA0ceB6D2e539a432
    // ERC-8004 ReputationRegistry (testnet): 0x8004B663056A597Dffe9eCcC1965A193B7388713
    // ERC-8004 ReputationRegistry (mainnet): 0x8004BAa17C55a88189AE136b182e5fdA19dE9b63

    address public immutable USDC;
    address public immutable IDENTITY_REGISTRY;

    /// @dev 15-minute window for the owner to publish before a refund is claimable.
    uint256 public constant PUBLISH_WINDOW = 900; // seconds

    uint256 public agentTokenId;
    uint256 private _nextReportId;

    /// @dev Tracks USDC owed to buyers whose reports are still pending (not yet published or refunded).
    uint256 private _pendingFees;

    struct Report {
        uint256 reportId;
        address buyer;
        bytes32 pairId;
        uint256 paidAt;
        uint256 fee;
        bytes32 contentHash;
        bool published;
    }

    mapping(uint256 => Report) public reports;
    mapping(address => uint256[]) private _buyerReports;

    event ReportPaid(uint256 indexed reportId, address indexed buyer, bytes32 indexed pairId, uint256 amount);
    event ReportPublished(uint256 indexed reportId, bytes32 contentHash);
    event AgentRegistered(uint256 indexed tokenId);
    event Refunded(uint256 indexed reportId, address indexed buyer, uint256 amount);

    constructor(address initialOwner, address usdc, address identityRegistry) Ownable(initialOwner) {
        require(usdc != address(0), "USDC is zero");
        require(identityRegistry != address(0), "Identity registry is zero");
        USDC = usdc;
        IDENTITY_REGISTRY = identityRegistry;
    }

    function setAgentTokenId(uint256 tokenId) external onlyOwner {
        require(tokenId != 0, "TokenId is zero");
        require(agentTokenId == 0, "Agent token already set");

        agentTokenId = tokenId;
        emit AgentRegistered(tokenId);
    }

    function buyReport(bytes32 pairId) external nonReentrant returns (uint256 reportId) {
        require(pairId != bytes32(0), "PairId is zero");

        bool ok = IERC20(USDC).transferFrom(msg.sender, address(this), FEE);
        require(ok, "USDC transferFrom failed");

        reportId = _nextReportId;
        _nextReportId = reportId + 1;
        _pendingFees += FEE;

        reports[reportId] = Report({
            reportId: reportId,
            buyer: msg.sender,
            pairId: pairId,
            paidAt: block.timestamp,
            fee: FEE,
            contentHash: bytes32(0),
            published: false
        });

        _buyerReports[msg.sender].push(reportId);

        emit ReportPaid(reportId, msg.sender, pairId, FEE);
    }

    function publishReport(uint256 reportId, bytes32 contentHash) external onlyOwner {
        require(contentHash != bytes32(0), "Content hash is zero");

        Report storage report = reports[reportId];
        require(report.buyer != address(0), "Report does not exist");
        require(!report.published, "Already published");
        // Enforce publish deadline: owner cannot publish after the refund window opens.
        require(block.timestamp < report.paidAt + PUBLISH_WINDOW, "Publish window closed");

        report.contentHash = contentHash;
        report.published = true;
        _pendingFees -= FEE;

        emit ReportPublished(reportId, contentHash);
    }

    function refundIfStale(uint256 reportId) external nonReentrant {
        Report storage report = reports[reportId];
        require(report.buyer != address(0), "Report does not exist");
        require(report.buyer == msg.sender, "Not report buyer");
        require(!report.published, "Already finalized");
        require(block.timestamp >= report.paidAt + PUBLISH_WINDOW, "Too early for refund");

        report.published = true;
        report.contentHash = bytes32(type(uint256).max);
        _pendingFees -= FEE;

        bool ok = IERC20(USDC).transfer(msg.sender, FEE);
        require(ok, "USDC transfer failed");

        emit Refunded(reportId, msg.sender, FEE);
    }

    function withdrawFees(address to) external onlyOwner {
        require(to != address(0), "To is zero");
        uint256 withdrawable = IERC20(USDC).balanceOf(address(this)) - _pendingFees;
        require(withdrawable > 0, "Nothing to withdraw");
        bool ok = IERC20(USDC).transfer(to, withdrawable);
        require(ok, "USDC transfer failed");
    }

    /// @notice Returns the USDC amount currently locked for pending (unpublished, unrefunded) reports.
    function pendingFees() external view returns (uint256) {
        return _pendingFees;
    }

    function getReport(uint256 reportId) external view returns (Report memory) {
        return reports[reportId];
    }

    function myReports(address buyer) external view returns (uint256[] memory) {
        return _buyerReports[buyer];
    }

    function fee() external pure returns (uint256) {
        return FEE;
    }
}
