# FX Pulse

**Paid FX market notes on Arc Testnet.** An onchain AI analyst that sells 0.50 USDC research notes for stablecoin pairs (USDC/EURC, USDC/GBPA, USDC/JPYC).

> **Research only. Not financial advice. Not an offer to trade. Testnet only.**

---

## Deployed Contracts (Arc Testnet)

| Contract | Address |
|---|---|
| ReportDesk | [`0xb88ce5fb990b8c47fa5edfe2f4aed36ba7d4db7b`](https://explorer.testnet.arc.io/address/0xb88ce5fb990b8c47fa5edfe2f4aed36ba7d4db7b) |

Chain ID: `5042002` | USDC ERC-20: `0x3600000000000000000000000000000000000000`

---

## How to Use

### 1. Get test USDC
Click **Get test USDC** in the Arc Studio sidebar. This drips USDC to your connected wallet on Arc Testnet.

### 2. Connect your wallet
Click **Connect Wallet** in the app header. Make sure you're on Arc Testnet (chain ID 5042002).

### 3. Approve 0.50 USDC
The app will prompt you to approve 0.50 USDC (500,000 in 6-decimal atomic units) to the ReportDesk contract. This is a standard ERC-20 `approve` call — the app checks your existing allowance and skips this step if you've already approved enough.

### 4. Buy a note
Select a pair (USDC/EURC, USDC/GBPA, or USDC/JPYC) and click **Approve 0.50 USDC + Buy Note**. This:
1. Approves USDC if needed
2. Calls `buyReport(pairId)` — transfers 0.50 USDC to the contract
3. Generates the FX note offchain
4. Calls `publishReport(reportId, contentHash)` — stores the keccak256 of the note onchain

### 5. Read the note
The note card shows bias (long base / long quote / neutral), a confidence bar (50–100), three market drivers, and the onchain content hash.

### Stale report refund
If the owner fails to publish within **15 minutes** of payment, the buyer can call `refundIfStale(reportId)` to reclaim their 0.50 USDC. The publish window strictly closes at `paidAt + 900s` — the owner cannot publish after this window (enforced in the contract).

---

## The Stub Analyst

By default the app uses a deterministic stub analyst:
- **Bias**: derived from a djb2 hash of the pair name and the current UTC hour.
- **Confidence**: 50–70 range, seeded from the same hash.
- **Drivers**: three canned, pair-specific drivers. The last one notes "stub feed — not live prices."
- **mid / change24hPct**: `null`.

### Using a live price feed

Set `VITE_PRICE_API_URL` in `.env` to a URL that accepts a `?pair=USDC/EURC` query parameter and returns JSON:

```json
{ "last": 1.0823, "change24hPct": 0.12 }
```

When this variable is set, the analyst fetches live data, adjusts the bias from the 24h change, and populates `mid` and `change24hPct` in the note.

---

## Contract Architecture

### ReportDesk.sol

| Function | Who | What |
|---|---|---|
| `buyReport(pairId)` | Any buyer | Pays FEE, creates a report record |
| `publishReport(reportId, hash)` | Owner only | Stores the note hash onchain (must be within 15 min) |
| `refundIfStale(reportId)` | Original buyer | Refunds if not published after 15 min |
| `withdrawFees(to)` | Owner only | Withdraws **earned** fees (published reports only) |
| `setAgentTokenId(tokenId)` | Owner once | Records ERC-8004 token ID |
| `pendingFees()` | View | USDC locked for pending reports |

### Security notes
- `_pendingFees` tracks locked USDC: `withdrawFees` can only pull `balance - _pendingFees`. The owner cannot drain buyer refunds.
- `publishReport` enforces a hard deadline at `paidAt + 900s`. After that it reverts; the buyer's refund path is guaranteed.
- OpenZeppelin Ownable + ReentrancyGuard. No unbounded loops. Audited and 51 unit tests pass.

---

## ERC-8004 Agent Identity

The contract includes a `setAgentTokenId` function. After deploying, the owner registers the agent via:

```solidity
// Call from the owner wallet (Arc Testnet)
IIdentityRegistry(0x8004A818BFB912233c491871b3d84c89A494BD9e).register(
  "https://<your-app-host>/agent.json"
);
// Then call:
reportDesk.setAgentTokenId(<returned tokenId>);
```

The agent card JSON is served at `/agent.json` (static public file).

---

## Pointing at Mainnet (manual process)

Mainnet deploy is a manual, owner-operated step:

1. Deploy `ReportDesk.sol` from your own wallet using `forge create` or Hardhat.
2. Update `REPORT_DESK_ADDRESS` in `src/contracts.ts` to the mainnet address.
3. Register on the Arc Mainnet IdentityRegistry: `0x8004A169FB4a3325136EB29fA0ceB6D2e539a432`
4. Update `agentRegistry` in `public/agent.json` to use chain ID `5042`.

Arc Studio does not deploy or operate on mainnet. All mainnet operations are your responsibility.

---

## Local Development

```bash
bun install
bun run dev
```

```bash
# Run Foundry tests
forge test
```
